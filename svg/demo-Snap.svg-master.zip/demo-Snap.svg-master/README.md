demo-Snap.svg
=====================
It makes the study of Snap.svg simpler. It translated official documents to Chinese, meanwhile, add many demos for explaining how to use these apis.

If your PC support PHP, you can download and view at local. Otherwise, you can <a href="http://www.zhangxinxu.com/GitHub/demo-Snap.svg/demo/basic/Element.add.php">click here</a> for a visit.

License
--------------------------
Under The MIT Micense