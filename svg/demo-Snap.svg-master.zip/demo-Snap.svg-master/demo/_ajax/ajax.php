<?php
    echo '#' . rand(0, 9). rand(0, 9). rand(0, 9);
?>